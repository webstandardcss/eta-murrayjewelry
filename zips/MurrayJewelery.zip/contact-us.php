<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
		
			<h2 class="text-center">Contact Us</h2>
			<h1 class="text-center">Our hours of operation are:</h1>
			
			<p>Monday – Friday 10:00 am to 6:00 pm<br />

and Saturday by appointment only.<br />

Call us at (903) 753-7133</p>
			
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
		
			<h2 class="text-center">Location</h2>
			<h2 class="text-center">MURRAY JEWELRY’s SHOWROOM LOCATION</h2>
			
			<p>2320 Judson Road<br />
Longview, Texas 75605n. </p>
			<br />
			
			<div class="text-center">
				<iframe width="650" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=d&amp;source=s_d&amp;saddr=Murray+Jewelry+Co,+2320+Judson+Road,+Longview,+TX+75605&amp;daddr=&amp;geocode=CZHQ7H7UVGJbFex58AEd8k5a-impCtXBtDg2hjFL27_xmH46Hg&amp;sll=32.537068,-94.744846&amp;sspn=0.00833,0.016512&amp;gl=us&amp;hl=en&amp;mra=mift&amp;ie=UTF8&amp;t=m&amp;ll=32.537063,-94.744849&amp;spn=0.009045,0.013926&amp;z=16&amp;output=embed"></iframe>
			</div>
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
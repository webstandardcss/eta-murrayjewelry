<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<div class="text-center">
				<img src="images/Jolie-2.jpg" class="img-responsive img-fix" style="width: 300px;" />
			</div>
		
			<h2 class="text-center">Ziva Jewels</h2>
			
			<img src="images/Ziva-Oval-Ring.png" class="img-responsive img-fix" style="width: 300px;" />
			<br />
			<p>For over 20 years, Ziva has been creating beautiful bridal and fashion jewelry for the trade. All of their jewelry is designed and manufactured in the United States. ZIVA provides one of the most up to date, comprehensive collections of fine jewelry available.</p>
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
<?php include_once('header.php'); ?> 
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<img src="images/Rolex-cover.jpg" class="img-responsive" />
		
			<h2 class="text-center">Rolex</h2>
			
			<div class="text-center">
				<iframe style="margin: auto; float: none;" width="560" height="315" src="https://www.youtube.com/embed/qQSIr5zS9Sw?rel=0&amp;autoplay=1" "frameborder="0" allowfullscreen=""></iframe>
				<br />
			</div>
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?> 
<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<div class="text-center">
				<img src="images/star-129-diamonds.png" class="img-responsive img-fix" />
			</div>
		
			<h2 class="text-center">Diamond Search</h2>
			
			<div class="text-center">
			<iframe src="http://www.om-diamonds.com/search-tool/?key=04169c630a9f0b0c8d6e3290bfe3953c" height="1000" width="750" frameborder="0" scrolling="no"></iframe>
			</div>
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
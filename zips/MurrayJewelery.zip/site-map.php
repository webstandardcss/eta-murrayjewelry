<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
		
			<h2 class="text-center">Site Map</h2>
			
			<p><a title="Murray Jewelry " href="http://murrayjewelry.com/"><span style="text-decoration: underline;">The Murray Jewelry Home Page</span> </a><br>
We Work with you to provide service and quality…</p>
<p><a title="About Us " href="http://murrayjewelry.com/?page_id=12"><span style="text-decoration: underline;">About Us</span> </a><br>
Established in 1959 and still going strong…</p>
<p><a title="Contact Us " href="http://murrayjewelry.com/?page_id=14"><span style="text-decoration: underline;">Contact Us</span> </a><br>
By Phone or by Email…</p>
<p><a title="Location" href="http://murrayjewelry.com/?page_id=13"><span style="text-decoration: underline;">Our Store Location…</span> </a><br>
By Phone or by Email.</p>
<p><span style="text-decoration: underline;"><a href="http://murrayjewelry.com/?page_id=6">Our Jewelry Selection</a></span><br>
The Best Selection of Popular Jewelry Designs…</p>
<p><span style="text-decoration: underline;"><a href="http://murrayjewelry.com/?page_id=7">Our Watches and Accessories</a></span><br>
Quality Watches and Timepiece destin to become heirlooms…</p>
<p><a href="http://murrayjewelry.com/?page_id=8"><span style="text-decoration: underline;">Our Services</span> </a><br>
We provide serives from our showroom location for your convenience…</p>
<p><a href="http://murrayjewelry.com/?page_id=9"><span style="text-decoration: underline;">Jewelry and Watch Repair</span> </a><br>
Nearly all repairs are performed in-house…</p>
<p><span style="text-decoration: underline;"><a href="http://murrayjewelry.com/?page_id=10">Our Layaway Option</a></span><br>
We help you get that very special piece that you want…</p>
			
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
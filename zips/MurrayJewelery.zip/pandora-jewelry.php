<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<div class="text-center">
				<img src="images/tile_pandora2.jpg" class="img-responsive img-fix" style="width: 300px;" />
			</div>
		
			<h2 class="text-center">Pandora Jewelry</h2>
			
			<p>Pandora is an exciting and fascinating series of jewelry which, lust like Pandora’s box, opens up countless opportunities. You design your bracelet yourself, so that it expresses your very own style and your unforgettable moments. The Pandora series is a Danish design and is made of sterling silver and 14K gold. Murray Jewelry carries an extensive selection of Pandora, so you may creatively express yourself. Click <a href="http://www.pandora.net/en-us" target="_blank">here</a> to start your Pandora Wishlist today!</p>
			
			<img src="images/Timeline-Eng_Disney4.jpg" class="img-responsive img-fix" />
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
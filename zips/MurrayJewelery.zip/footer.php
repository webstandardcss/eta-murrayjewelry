<footer>
		<!-- Footer Starts -->
		
			<article class="footer-top">
				<a href="#" target="_blank"><img src="images/icon-fb-b.png" /></a>
				<a href="#" target="_blank"><img src="images/icon-tw-b.png" /></a>
				<a href="#" target="_blank"><img src="images/icon-u-b.png" /></a>
				<a href="#" target="_blank"><img src="images/icon-pin-b.png" /></a>
			</article>
			
			<section class="footer-contents container">
			<div class="">
			<!-- Footer Contents Starts -->
			
				<article class="each-footer col-sm-3">
				<!-- Each Column Starts -->
				
					<h3>Murray Jewelry Address</h3>
					<p>2320 Judson Rd<br />
					Longview, Texas</p>
				
				<!-- Each Column Ends -->
				</article>
			
				<article class="each-footer col-sm-3">
				<!-- Each Column Starts -->
				
					<h3>Murray Jewelry Address</h3>
					<p>2320 Judson Rd<br />
					Longview, Texas</p>
				
				<!-- Each Column Ends -->
				</article>
			
				<article class="each-footer col-sm-3">
				<!-- Each Column Starts -->
				
					<h3>Murray Jewelry Address</h3>
					<p>2320 Judson Rd<br />
					Longview, Texas</p>
				
				<!-- Each Column Ends -->
				</article>
			
				<article class="each-footer col-sm-3">
				<!-- Each Column Starts -->
				
					<h3>Murray Jewelry Address</h3>
					<p>2320 Judson Rd<br />
					Longview, Texas</p>
				
				<!-- Each Column Ends -->
				</article>
			
			<!-- Footer Contents Ends -->
			</div>
			</section>
		
			<article class="footer-bottom">
				MURRAY JEWELRY | 2320 JUDSON ROAD LONGVIEW, TEXAS 75604 - 903 753-7133 | WE ARE CERTIFIED MEMEBERS OF THE "AMERICAN GEM SOCIETY" | WEB DESIGN BY WEB STANDARD CSS 
			</article>
		
		<!-- Footer Ends -->
		</footer>
	
	</body>
</html>
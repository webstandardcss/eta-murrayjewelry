<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<img src="images/Seiko.jpg" class="img-responsive" width="100%" />
		
			<h2 class="text-center">Watches</h2>
			
			<p>Murray Jewelry offers several line of watches to fit every lifestyle whether it’s our own line of Murray watches made by Belair, or our Seiko and Reactor lines.</p>
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
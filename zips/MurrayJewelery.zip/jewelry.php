<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<div class="text-center">
				<img src="images/header3.jpg" class="img-responsive img-fix" />
			</div>
		
			<h2 class="text-center">Jewelry</h2>
			
			<p>Murray Jewelry would love the opportunity to guide you through the buying process and provide you very competitive pricing in a local setting.</p>

			<p>As well, we carry an extensive selection of popular jewelry design lines, including:</p>
			<ul>
				<li>Bellarri</li>
				<li>Charles Krypell</li>
				<li>Pandora Jewelry</li>
				<li>Ziva Jewels</li>
			</ul>
			
			<img src="images/Murray_Footer.jpg" class="img-responsive img-fix" />
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
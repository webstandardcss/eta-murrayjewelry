<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
		
			<h2 class="text-center">Layaway</h2>
			<h1 class="text-center">OUR LAYAWAY SERVICES</h1>
			
			<p>Murray Jewelry offers Layaway for In-Store Merchandise.<br />
We make it easy for you to get that special item.</p>

			<p>Layaway an item for up to One Year<br />
Pay only 20% Down<br />
With 10% Payment per Month</p>
			
			<p>* Sorry, No Cash Refunds on Layaways.</p>
			
			<p>Don’t Know What to Get??<br />
Murray Jewelry also offers Gift Certificates.<br />
You Spend What You Want and They Select Exactly the Gift They Want!</p>
			
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
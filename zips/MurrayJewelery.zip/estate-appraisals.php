<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
		
			<h2 class="text-center">Estate Appraisals</h2>
			
			<p>Murray Jewelry performs AGS Certified services including appraisals and engravings.</p>

			<p>We can perform two types of appraisals, Insurance Replacement Appraisals and Estate Appraisals.</p>
			
			<p>We provide engraving services for items purchased in our store. Other services include our Layaway program, Gift Certificate Purchase Option and Stone </p>
			
			<img src="images/apprasial.jpg" class="img-responsive img-fix" style="width: 300px;" />
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>
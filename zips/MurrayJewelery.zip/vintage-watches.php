<?php include_once('header.php'); ?>
		
		<section class="main-contents container">
		<div class="3">
		<!-- Main Contents Starts -->
			
			<div class="text-center">
				<img src="images/header3.jpg" class="img-responsive img-fix" />
			</div>
		
			<h2 class="text-center">Early 1960′s Blancpain Aqua Lung Military. 1700 cal. Rare and unusual!</h2>
			
			
			
			<img src="images/10443147_1449481951986643_5460687389572288178_o-224x300.jpg" class="img-responsive img-fix" style="width: 200px" />
			
		<!-- Main Contents Ends -->
		</div>
		</section>
		
<?php include_once('footer.php'); ?>